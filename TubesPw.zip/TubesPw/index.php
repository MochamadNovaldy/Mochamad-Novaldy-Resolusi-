<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Index</title>
	<style>
		body {
			background-color: aqua;

		}
	</style>
</head>
<body>
	<h1 align="center">Halaman Index</h1>
	<br>
	<h1 align="center">Pertemuan 3</h2>
	<h2 align="center"><a href="Pertemuan3/Latihan3a.php">== Latihan3a_183040048 ==</a></h2>
	<h2 align="center" ><a href="Pertemuan3/Latihan3b.php">== Latihan3b_183040048 ==</a></h2>
	<h2 align="center"><a href="Pertemuan3/Latihan3c.php">== Latihan3c_183040048 ==</a></h2>
	<h2 align="center"><a href="Pertemuan3/Latihan3d.php">== Latihan3c_183040048 ==</a></h2>
	<h1 align="center">Pertamuan 4</h2>
	<h3 align="center" ><a href="Pertemuan4/Latihan/Latihan4a.php">== Latihan2a_183040048 ==</a></h2>
	<h3 align="center"><a href="Pertemuan4/Latihan/Latihan4b.php">== Latihan2b_183040048 ==</a></h2>
	<h3 align="center"><a href="Pertemuan4/Latihan/Latihan4c.php">== Latihan2c_183040048 ==</a></h2>
	<h3 align="center"><a href="Pertemuan4/Latihan/Latihan4d.php">== Latihan2d_183040048 ==</a></h2>
	<h1 align="center">Pertamuan 5</h2>
	<h3 align="center" ><a href="Pertemuan5/latihan/Latihan5a_183040057.php">== Latihan5a_183040048 ==</a></h2>
	<h3 align="center" ><a href="Pertemuan5/latihan/Latihan5b_183040057.php">== Latihan5b_183040048 ==</a></h2>
	<h3 align="center" ><a href="Pertemuan5/latihan/Latihan5c_183040057.php">== Latihan5c_183040048 ==</a></h2>
	<h3 align="center" ><a href="Pertemuan5/latihan/Latihan5d_183040057.php">== Latihan5d_183040048 ==</a></h2>
	<h3 align="center" ><a href="Pertemuan5/latihan/Latihan5e_183040057.php">== Latihan5e_183040048 ==</a></h2>
	<h1 align="center">Pertamuan 6</h2>
	<h3 align="center" ><a href="Pertemuan6/latihan6a_183040057/indexs.php">== Latihan6a_183040048 ==</a></h2>
	<h3 align="center" ><a href="Pertemuan6/latihan6b_183040057/indexs.php">== Latihan6b_183040048 ==</a></h2>
	<h3 align="center" ><a href="Pertemuan6/latihan6c_183040057/indexs.php">== Latihan6c_183040048 ==</a></h2>
	<h1 align="center">Pertamuan 7</h2>
	<h3 align="center" ><a href="Pertemuan7/index.php">== Latihan7a_183040048 ==</a></h2>
	<h3 align="center" ><a href="Pertemuan8/index.php">== Latihan7a_183040048 ==</a></h2>
	<h3 align="center" ><a href="Pertemuan9/index.php">== Latihan8a_183040048 ==</a></h2>
	<h1 align="center">Tugas</h2>
	<h4 align="center"><a href="Pertemuan4/Tugas/Tugas2.php">== Tugas2_183040048 ==</a></h2>
	<h4 align="center"><a href="Tugas3/login_admin.php">== Tugas3_183040048 ==</a></h2>
</body>
</html>