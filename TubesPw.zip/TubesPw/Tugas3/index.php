 <?php
//Connect To Databases => funtions
require 'funtions.php';
//Query data Tabel Film
$mobil = query("SELECT * FROM mobil3");


if( isset($_POST["cari"]) ) {
	$mobil = cari($_POST["keyword"]);
}
 
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Daftar Mobil</title>
</head>
<body> 
	<h2 align="center">Daftar Sorum Mobil Jaya Karawang</h2>
	
	<center><button><a href="tambah.php">Tambahkan Mobil</a></button></center>
		<br><br>
	<center><button type="submit"><a href="halaman_user.php">Logout</a></button></center>
	<br>
	<form action="" method="post">
		<center><input type="text" name="keyword" size="45" autofocus placeholder="Masukan keyword pencarian..." autocomplete="off">
		<button type="submit" name="cari">Cari!</button></center>
	</form>
	<br>
	<table align="center" border="1"  cellspacing="0" cellpadding="10">
			<tr>
				<th>no.</th>
				<th>nama_mobil</th>
				<th>harga_mobil</th>
				<th>kecepatan_mobil</th>
			</tr>
			<?php $i = 1; ?>	
				<?php foreach($mobil as $mobil) : ?>
			<tr>
				<td><?= $i++; ?></td>
				<td><a href="ubah.php?id=<?= $brg["id"]; ?> ">Ubah</a> | 
					<a href="hapus.php?id=<?= $brg["id"]; ?>" onClick="return confirm('Yakin akan dihapus?')">Hapus</a>
				</td>
				<td><?= $mobil['nama_mobil']; ?></td>
				<td><?= $mobik['harga_mobil']; ?></td>
				<td><?= $mobil['kecepatan_mobil']; ?></td>
			</tr>
				<?php endforeach; ?>
	</table>
	
	
</body>
</html> 