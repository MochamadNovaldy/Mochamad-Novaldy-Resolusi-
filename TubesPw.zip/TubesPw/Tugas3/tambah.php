<?php
//Connet To Databases
require 'function.php';
//Tombol Submit mengecek sudah di tekan atau belum
if( isset($_POST["submit"]) ) {
//Pengecekan Berhasil Apa gagal
	if( tambah($_POST) > 0 ) {
		print "
			<script>
				alert('Data Berhasil Ditambahkan!');
				document.location.href = 'index3.php';
			</script>
		";
	} else {
		print "
			<script>
				alert('Data Gagal Ditambahkan!');
				document.location.href = 'index3.php';
			</script>
		";
	}
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Daftar Mobil</title>
</head>
<body>
	<h2>Tambah Daftar Mobil</h2>
		<form method="post" action="">
			<ul>
				<li>
				<label for="Masukan nama mobill">Masukan nama mobil : </label> 
				<br>
				<input type="text" name="nama" required>
				</li>
				
				<br>
				
				<li>
				<label for="Masukan harga">Masukan Harga Mobil :</label>
				<br>
				<input type="text" name="harga" required>
				</li>
				
				<br>
				
				<li>
				<label for="Masukan List Kecepatan">Masukan Daftar Kecepatan:</label>	 
				<br>
				<input type="text" name="Kecepatan" required>
				</li>
				
				<br>
				
				<li>
				<label for="Masukan Penjualan">Masukan Penjualan :</label>	 
				<br>	 
				<input type="text" name="Penjualan" required>
				</li>
				
				<br>
				
				<li>

				</li>
				
				<br>
				
				<td>
					<button type="submit" name="submit">Tambah Data Mobil!</button>
				</td>
			</ul>
		</form>
	
	
	
	
</body>
</html>