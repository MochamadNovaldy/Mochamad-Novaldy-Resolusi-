  <?php
require 'function.php';
 $mobil = query("SELECT * FROM mobil");

 if( isset($_POST['cari'])) {
 	$mobil = cari($_POST['keyword']);
 }
 if(isset($_POST['submit'])) {
 	if ($_POST['username'] == 'admin' && $_POST['password'] == 'admin') {
 		header("location: index3.php");
 		exit;
 	}else{
 		$nValid = true;
 	}
 }
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>183040048</title>
</head>
	<style>
		.container {
			text-align: center;
		}
		.content {
			
		}
		.gambar {
			
			
		}
	</style>
<body bgcolor="yellow">
	<center><h2>Daftar Mobil</h2></center>
	<form action="" method="post">
		<div class="Login">
          <center><a href="Login_admin.php">Login sebagai admin</a></center>
            </div>
            <br><br>
            <center><input type="text" name="keyword" size="45" autofocus placeholder="Masukan keyword pencarian mobil" autocomplete="off">
            <button type="submit" name="cari">Cari</button></center>
	</form>
	<br>
 <div class="container">
 			<?php foreach ($mobil as $mobil) : ?>
        <div class="content">
            <p class="nama">
				<a href="Profil.php?id=<?= $mobil['id']; ?>"><?= $mobil['mobil']; ?></a>
			</p>
			<p><?= $brg['nama']; ?></p>
			<?php endforeach; ?>
        </div>
 </div>
</body>
</html>