<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>halaman admin</title>
</head>
<body>
	<center><h1>Selamat Datang Admin</h1></center>
	<center><button type="submit"><a href="Login_admin.php">Logout</a></button></center>
	
</body>
</html>