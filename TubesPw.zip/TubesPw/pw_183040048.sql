-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 20, 2020 at 07:51 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pw_183040048`
--

-- --------------------------------------------------------

--
-- Table structure for table `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `id` int(11) NOT NULL,
  `nrp` char(9) NOT NULL,
  `nama` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `jurusan` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mahasiswa`
--

INSERT INTO `mahasiswa` (`id`, `nrp`, `nama`, `email`, `jurusan`) VALUES
(1, '183040048', 'novaldy', 'novaldy@gmail.com', 'Teknik informatika'),
(2, '183040032', 'genji', 'gejiyaaa12@gmail.com', 'Teknik industri'),
(3, '183040077', 'naruto', 'uzumakinaruto@gmail.com', 'Teknik mesin'),
(4, '183040067', 'yamato boyen', 'boyen_yamato12@gmail.com', 'Teknik informatika'),
(5, '183040022', 'asgar thor', 'asgar_thor@gmail.com', 'Teknik pangan'),
(6, '183040066', 'hadi', 'hadi@gmail.com', 'Teknik pangan'),
(7, '183040034', 'sandi', 'sandi123@gmail.com', 'Teknik industri');

-- --------------------------------------------------------

--
-- Table structure for table `mobil`
--

CREATE TABLE `mobil` (
  `id` int(5) NOT NULL,
  `nama_mobil` varchar(20) NOT NULL,
  `harga_mobil` varchar(20) NOT NULL,
  `kecepatan_mobil` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mobil`
--

INSERT INTO `mobil` (`id`, `nama_mobil`, `harga_mobil`, `kecepatan_mobil`) VALUES
(1, 'Lamborghini', '74.6 Miliar', '349 km / h (217 mph)'),
(2, 'Aston Martin', '4,5 Milyar', '00 km / h (62 mph'),
(3, 'Mercedes-BenzC200', '975 Juta', '223 sampai 250km/jam'),
(4, 'bmw i8', '4.651.000.000', '250 km/jam (155 mph)');

-- --------------------------------------------------------

--
-- Table structure for table `mobil1`
--

CREATE TABLE `mobil1` (
  `id` int(5) NOT NULL,
  `nama_mobil` varchar(20) NOT NULL,
  `harga_mobil` varchar(20) NOT NULL,
  `kecepatan_mobil` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mobil1`
--

INSERT INTO `mobil1` (`id`, `nama_mobil`, `harga_mobil`, `kecepatan_mobil`) VALUES
(1, 'bantley', '16 Milyar', '306 km/jam'),
(2, 'bugatti chiron', '49 miliar', '16 km/jam'),
(3, 'Ferrari 458', '12 Milyar', '325 km/jam'),
(4, 'Fiat 500', '425 Juta', '1100 rev/menit');

-- --------------------------------------------------------

--
-- Table structure for table `mobil2`
--

CREATE TABLE `mobil2` (
  `id` int(5) NOT NULL,
  `nama_mobil` varchar(20) NOT NULL,
  `harga_mobil` varchar(20) NOT NULL,
  `kecepatan_mobil` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mobil2`
--

INSERT INTO `mobil2` (`id`, `nama_mobil`, `harga_mobil`, `kecepatan_mobil`) VALUES
(1, 'Jeep Rubicon', '1,78 miliar', '3000 cc'),
(2, 'Nissan GT-R ', '1,6 miliar', '3799 cc'),
(3, 'nissan serena', ' 462,9 Juta', '1997 cc'),
(4, 'fortuner', '493 juta', '2393 cc');

-- --------------------------------------------------------

--
-- Table structure for table `mobil3`
--

CREATE TABLE `mobil3` (
  `id` int(11) NOT NULL,
  `nama_mobil` varchar(20) NOT NULL,
  `harga_mobil` varchar(20) NOT NULL,
  `kecepatan_mobil` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mobil3`
--

INSERT INTO `mobil3` (`id`, `nama_mobil`, `harga_mobil`, `kecepatan_mobil`) VALUES
(1, 'rolls royce', '20 Miliar', '6749 cc'),
(2, 'Lexus LC 500', '4.300.000.000', '4969 cc'),
(3, 'Xpander', '275,1 Juta', '1499 cc'),
(4, 'brio', '146 juta', '1199 cc'),
(5, 'pejero sport', '491,5 juta', '2.500 cc'),
(6, 'Toyota Alphard', '1,041 miliar', '2.500 cc'),
(7, 'ayla', '102,2 juta', '1.000 CC'),
(8, 'avanza', '200,2 Juta', '1,329 cc');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(1, 'novaldy', '$2y$10$TAA01NGJSh8EAaSuQUbi5OIZfsce8UGZcqDclq2xM4IsUTgShVtCe'),
(2, 'admin', '$2y$10$jaIFh.l1uAbmNLwVqWgDzuah.AX/AoANA8qOH6mAl7i.WJ0MUSbDy'),
(3, 'tes', '$2y$10$G7l8K7oLQzM2RhH7Tk/5n.k7H6FM9YiNJpNXOFujimptihLH8ehjC'),
(4, 'cek', '$2y$10$SKWSwh4bpFwctezT7F1E2.6DLzCgOPVYsp12gXCD2yNxJ4nZRMsj2'),
(5, 'syamsul', '$2y$10$prNj3Ef5/Od81DrNdTQIUuz7rdPTQiN/O3fbT9NAEf9jqMgORSPga'),
(6, 'deni', '$2y$10$VoG6Vn9RQ0HDY6b0Xt8oM.sILA.qNcMnzccNuzOv9GUgzDbeYIz2.'),
(7, 'reza', '$2y$10$22z/unwwS964p.c3EJK1HuijHE319BivBonwbTTH9V7lQakEIZ60q'),
(8, 'walker cans', '$2y$10$oiksp/nWiCHviReP2CQAe.azoS7j89hZ1uzGOBtE0/WUmLpit7ymu'),
(9, 'adut', '$2y$10$rx1dKdS2WXgRWII/t3RLl.oX14Y/klRye5zjHtViXrcCX2kqZYxIy'),
(10, 'ava', '$2y$10$w1eQ2iX2dhaaga8KO9u0/OMa7/PLzHetXHwgXsy7Uuz5fozxkix.2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `nama` (`nama`);

--
-- Indexes for table `mobil`
--
ALTER TABLE `mobil`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mobil1`
--
ALTER TABLE `mobil1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mobil2`
--
ALTER TABLE `mobil2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mobil3`
--
ALTER TABLE `mobil3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `mobil`
--
ALTER TABLE `mobil`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `mobil1`
--
ALTER TABLE `mobil1`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `mobil2`
--
ALTER TABLE `mobil2`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `mobil3`
--
ALTER TABLE `mobil3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
