<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<div class="container mt-4">
  <div class="row">
    <div class="col">
      <h1>Perkenalkan Saya <u> Mochamad Novaldy </u>  dari Universitas Pasundan.</h1>
      <p>Here it is <a href="/pages/about">about me</a>. And this is my <a href="/pages/contact">contact</a>.</p>
    </div>
  </div>
</div>
<?= $this->endSection() ?>