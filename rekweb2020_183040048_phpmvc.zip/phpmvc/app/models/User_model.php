<?php

class User_model
{
    private $nama = 'Novaldy';

    public function getUser()
    {
        return $this->nama;
    }
}
